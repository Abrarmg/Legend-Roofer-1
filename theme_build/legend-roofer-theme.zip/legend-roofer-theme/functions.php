<?php
function legend_roofer_setup() {
    add_theme_support( 'title-tag' );
}
add_action( 'after_setup_theme', 'legend_roofer_setup' );
